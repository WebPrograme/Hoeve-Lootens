import { getRequest } from '../modules/Requests.js';

const image = document.getElementById('photowall-image');
const caption = document.querySelector('.photowall-caption-text');

getRequest('/api/photowall/order/next').then((response) => {
	if (response.status !== 200) {
		console.error('Failed to fetch photos:', response.status);
		return;
	}

	let photo = response.data;

	function displayPhoto() {
		image.src = photo.URL;
		caption.textContent = photo.Caption || '';

		// After displaying the current photo, fetch the next one after a delay
		setTimeout(() => {
			getRequest('/api/photowall/order/next').then((response) => {
				if (response.status === 200) {
					photo = response.data; // Update the photo variable with the next photo
					displayPhoto(); // Display the next photo
				} else {
					console.error('Failed to fetch next photo:', response.status);
				}
			});
		}, 5000);
	}

	displayPhoto(); // Start displaying the photos
});
